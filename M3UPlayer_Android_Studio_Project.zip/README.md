# M3U Player — Android Studio project

Starter project for Android phones and Android TV / TV boxes.

## Features
- Load an M3U playlist from an HTTP(S) URL
- Import a local M3U/M3U8 file
- Parse channel names, group-title and tvg-logo metadata
- Search channel names and groups
- Play compatible HTTP(S) streams with AndroidX Media3 ExoPlayer
- Long-press a channel to favorite/unfavorite it for the current session
- Dark interface with TV launcher category and D-pad-focusable controls

## Build the APK
1. Install Android Studio and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Wait for Gradle sync.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Debug APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Important
This ZIP contains editable source code, not a precompiled APK. Android Studio and the Android SDK are needed to compile it. Use only playlists and streams you own or are authorized to access. No channels, subscriptions, or playlists are included. Some providers require extra authentication, DRM, or format-specific integration not included in this starter.
