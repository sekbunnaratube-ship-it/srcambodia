package com.example.m3uplayer

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.content.Intent
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

data class Channel(val name: String, val url: String, val group: String = "Other", val logo: String? = null)

class MainActivity : AppCompatActivity() {
    private val bg = Color.rgb(8, 13, 24)
    private val panel = Color.rgb(17, 26, 43)
    private val blue = Color.rgb(53, 183, 255)
    private val white = Color.WHITE
    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var channelList: ListView
    private lateinit var status: TextView
    private lateinit var count: TextView
    private lateinit var search: EditText
    private var channels: List<Channel> = emptyList()
    private var visibleChannels: List<Channel> = emptyList()
    private val favorites = mutableSetOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
        player = ExoPlayer.Builder(this).build()
        playerView.player = player
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(16))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = TextView(this).apply {
            text = "M3U PLAYER"; textSize = 22f; setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
        }
        header.addView(brand)
        header.addView(Space(this), LinearLayout.LayoutParams(0, 1, 1f))
        header.addView(button("+ PLAYLIST") { showPlaylistDialog() })
        root.addView(header, LinearLayout.LayoutParams(-1, dp(52)))

        status = TextView(this).apply {
            text = "Add an M3U playlist URL or import a playlist file"
            textSize = 13f; setTextColor(Color.LTGRAY)
            setPadding(0, dp(5), 0, dp(10))
        }
        root.addView(status)

        val content = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val left = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(panel); setPadding(dp(10))
        }
        search = EditText(this).apply {
            hint = "Search channels"; setSingleLine(true); textSize = 14f
            setTextColor(white); setHintTextColor(Color.GRAY)
            setBackgroundColor(Color.rgb(29, 41, 61)); setPadding(dp(10))
            addTextChangedListener(SimpleTextWatcher { filterChannels(it) })
        }
        left.addView(search, LinearLayout.LayoutParams(-1, dp(44)))
        count = TextView(this).apply {
            text = "CHANNELS  ·  0"; setTextColor(blue); textSize = 12f
            typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(12), 0, dp(8))
        }
        left.addView(count)
        channelList = ListView(this).apply {
            divider = android.graphics.drawable.ColorDrawable(Color.rgb(40, 53, 72))
            dividerHeight = dp(1)
            setOnItemClickListener { _, _, position, _ ->
                visibleChannels.getOrNull(position)?.let { play(it) }
            }
            setOnItemLongClickListener { _, _, position, _ ->
                val c = visibleChannels.getOrNull(position) ?: return@setOnItemLongClickListener true
                if (!favorites.add(c.url)) favorites.remove(c.url)
                status.text = if (c.url in favorites) "Added ${c.name} to favorites" else "Removed ${c.name} from favorites"
                channelList.adapter = ChannelAdapter(visibleChannels)
                true
            }
        }
        left.addView(channelList, LinearLayout.LayoutParams(-1, 0, 1f))

        val right = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0)
        }
        playerView = PlayerView(this).apply {
            useController = true; setBackgroundColor(Color.BLACK); controllerAutoShow = true
        }
        right.addView(playerView, LinearLayout.LayoutParams(-1, 0, 1f))
        right.addView(TextView(this).apply {
            text = "Select a channel to play  •  Long-press to favorite"
            setTextColor(Color.LTGRAY); textSize = 12f; setPadding(0, dp(10), 0, dp(4))
        })
        content.addView(left, LinearLayout.LayoutParams(0, -1, 0.38f))
        content.addView(right, LinearLayout.LayoutParams(0, -1, 0.62f))
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun showPlaylistDialog() {
        val input = EditText(this).apply {
            hint = "https://example.com/playlist.m3u"; setTextColor(white)
            setHintTextColor(Color.GRAY); setPadding(dp(12))
        }
        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle("Add playlist URL").setView(input)
            .setPositiveButton("Load") { _, _ ->
                input.text.toString().trim().takeIf { it.isNotEmpty() }?.let { loadFromUrl(it) }
            }
            .setNeutralButton("Import file") { _, _ ->
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
                }
                startActivityForResult(intent, 2001)
            }.setNegativeButton("Cancel", null).create()
        dialog.show()
        dialog.getButton(-1)?.setTextColor(blue)
        dialog.getButton(-3)?.setTextColor(blue)
    }

    private fun loadFromUrl(address: String) {
        status.text = "Loading playlist…"
        lifecycleScope.launch {
            try {
                val text = withContext(Dispatchers.IO) {
                    val connection = URL(address).openConnection() as HttpURLConnection
                    connection.connectTimeout = 15000; connection.readTimeout = 20000
                    connection.setRequestProperty("User-Agent", "M3UPlayer/1.0")
                    try { connection.inputStream.bufferedReader().use { it.readText() } }
                    finally { connection.disconnect() }
                }
                setChannels(parseM3u(text))
            } catch (e: Exception) {
                status.text = "Could not load playlist: ${e.message ?: "check the URL"}"
            }
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 2001 && resultCode == Activity.RESULT_OK) {
            val uri: Uri = data?.data ?: return
            lifecycleScope.launch {
                try {
                    val text = withContext(Dispatchers.IO) {
                        contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                            ?: error("Unable to read file")
                    }
                    setChannels(parseM3u(text))
                } catch (e: Exception) { status.text = "Could not read playlist: ${e.message}" }
            }
        }
    }

    private fun parseM3u(text: String): List<Channel> {
        val result = mutableListOf<Channel>()
        var name = "Unknown channel"; var group = "Other"; var logo: String? = null
        text.lineSequence().forEach { raw ->
            val line = raw.trim()
            if (line.startsWith("#EXTINF", true)) {
                name = line.substringAfter(",", "Unknown channel").trim().ifBlank { "Unknown channel" }
                group = Regex("group-title=[\\\"']([^\\\"']+)", RegexOption.IGNORE_CASE)
                    .find(line)?.groupValues?.get(1) ?: "Other"
                logo = Regex("tvg-logo=[\\\"']([^\\\"']+)", RegexOption.IGNORE_CASE)
                    .find(line)?.groupValues?.get(1)
            } else if (line.isNotEmpty() && !line.startsWith("#") &&
                (line.startsWith("http://") || line.startsWith("https://"))) {
                result.add(Channel(name, line, group, logo))
                name = "Unknown channel"; group = "Other"; logo = null
            }
        }
        return result
    }

    private fun setChannels(items: List<Channel>) {
        channels = items; visibleChannels = items
        channelList.adapter = ChannelAdapter(items)
        count.text = "CHANNELS  ·  ${items.size}"
        status.text = if (items.isEmpty()) "No channels found. Check this is a valid M3U playlist."
            else "Playlist loaded: ${items.size} channels"
    }

    private fun filterChannels(query: String) {
        visibleChannels = if (query.isBlank()) channels else channels.filter {
            it.name.contains(query, true) || it.group.contains(query, true)
        }
        channelList.adapter = ChannelAdapter(visibleChannels)
        count.text = "CHANNELS  ·  ${visibleChannels.size}"
    }

    private fun play(channel: Channel) {
        status.text = "Playing: ${channel.name}"
        player?.setMediaItem(MediaItem.fromUri(channel.url))
        player?.prepare()
        player?.playWhenReady = true
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 12f; isAllCaps = false
        setTextColor(white); setBackgroundColor(Color.rgb(20, 103, 157))
        setOnClickListener { action() }; isFocusable = true
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        player?.release(); player = null
        super.onDestroy()
    }

    private inner class ChannelAdapter(private val data: List<Channel>) : BaseAdapter() {
        override fun getCount() = data.size
        override fun getItem(position: Int) = data[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val channel = data[position]
            val row = (convertView as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), dp(9), dp(8), dp(9))
                isFocusable = true; isFocusableInTouchMode = true
            }
            row.removeAllViews()
            row.addView(TextView(this@MainActivity).apply {
                text = (if (channel.url in favorites) "★  " else "") + channel.name
                textSize = 14f; setTextColor(white); maxLines = 1
                typeface = Typeface.DEFAULT_BOLD
            })
            row.addView(TextView(this@MainActivity).apply {
                text = channel.group; textSize = 11f; setTextColor(Color.LTGRAY); maxLines = 1
            })
            return row
        }
    }
}

private class SimpleTextWatcher(val changed: (String) -> Unit) : android.text.TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { changed(s?.toString() ?: "") }
    override fun afterTextChanged(s: android.text.Editable?) {}
}
